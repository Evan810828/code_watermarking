# LLM Watermarks on Code Generation — Pilot Study

## 1. Setting

**Model.** Qwen/Qwen3.5-4B (bf16). Prompts use the chat template with
`enable_thinking=False`; sampling: temperature 0.7, top_p 0.8, top_k 20,
max_new_tokens 512, seed 42.

**Datasets.** HumanEval test (164 tasks) and MBPP test (500 tasks), stored in
`data/`. HumanEval prompt: complete the given function signature in one
```` ```python ```` block; MBPP prompt: task text + the dataset's test cases,
answer in one code block. Plus LiveCodeBench `code_generation` test split
(release v1, 400 tasks, `data/livecodebench_test.json`), run with
`max_new_tokens=1024` and the official LCB generic prompt (system message +
question/format/answer, `src/dataloader/livecodebench.py`).

**Watermark methods.**

- **KGW** (Kirchenbauer et al. 2023): token-level green-list bias.
  Hyperparameters: `gamma=0.5, hash_key=15485863, prefix_length=1,
  f_scheme=time, window_scheme=left`, detection threshold z > 4.
  **`delta=8`** instead of the MarkLLM-default 2: at delta=2 the watermark is
  undetectable on code with this model (green fraction ≈ 0.49, z ≈ 0 —
  measured delta sweep: 2 → z≈−0.3, 4 → z≈1.5, 8 → z≈7.8), because code is
  too low-entropy for a +2 logit bias to flip tokens.
- **SemStamp** (Hou et al. 2024): segment-level semantic rejection sampling.
  SBERT embeddings (`AbeHou/SemStamp-c4-sbert`) are LSH-partitioned by
  `dimension_d=3` random hyperplanes into 8 regions, `gamma=0.25` of which
  are valid per step (seeded by the previous segment's region,
  `prime_P=15485863`); a segment is resampled until it is valid and at least
  `margin_m=0.01` from every hyperplane, with fallback after `N_max` trials.
  Detection: chain z-test over segments, threshold z > 3. Segmenters:
  `sent` = nltk sent_tokenize (the original; degenerate on code — median 1–3
  "sentences" per completion) and `line` = each non-blank line (the
  code-adapted analogue; median 9–19 segments).

**Implementations (each method run twice on HumanEval/MBPP, once with the
authors' original code on LCB).**

- *pilot*: own implementation following MarkLLM's algorithm code
  (`src/wm/kgw/`, `src/wm/semstamp/`), HF `transformers` inference
  (`src/run_kgw.py --impl pilot`, `src/run_semstamp.py --impl pilot`).
  KGW detection scores the generated token ids with their true left context.
  SemStamp pilot runs use the line segmenter with `N_max=32`
  (verified to give outputs identical to 100 when candidates are
  near-deterministic) and 16 candidates per rejection-sampling round.
- *MarkLLM+vLLM*: the official [THU-BPM/MarkLLM](https://github.com/THU-BPM/MarkLLM)
  package with vLLM 0.18 inference (`src/wm/markllm/`), run as an
  independent verification. KGW: MarkLLM's official vLLM-v1 logits processor
  + `KGW.detect_watermark` (standalone re-tokenized scoring; note current
  MarkLLM seeds its PRF `% vocab_size`, the pilot used the older
  `% (2**63−1)` — self-consistent each, aggregates comparable, per-token not).
  SemStamp: vLLM candidate sampling (32/round), accept/reject + masks +
  margin + detection all via MarkLLM components; `N_max=100` for line mode,
  32 for sent mode (whose candidates always fill the token budget). The
  released MarkLLM `N_max` fallback is unreachable dead code (it would
  resample forever on low-entropy text); the fallback is enforced as in the
  paper.
- *official* (LCB only): the ORIGINAL repos — KGW via `lm-watermarking`'s
  `extended_watermark_processor` (lefthash) and SemStamp via the released
  `SemStamp` code (`detect_lsh` detection, `sp_dim=3, lmbd=0.25,
  margin=0.02`, `MAX_TRIALS=32`) — not MarkLLM (`src/wm/official/`, run via
  `src/run_kgw.py --impl official` / `src/run_semstamp.py --impl official`).
  Segmenter is
  the original nltk `sent`: the released code has no line mode (`line` is
  this pilot's code adaptation), and on LCB `sent` is not degenerate —
  completions average 24.8 sentences vs 1–3 on HumanEval/MBPP. Two substantive shims, documented in `src/wm/official/semstamp.py`
  (official files untouched): a decode-consistent `SentenceEndCriteria`
  (chat-template fix) and enforcing the `N_max` fallback, which in the
  released code is the same unreachable dead code MarkLLM inherited. (Two
  trivial ones: an "-opt" model-name suffix to reach the model-agnostic
  generation branch, and a `bert_score` import stub.)

**Metrics.** TPR = detect rate on watermarked completions; FP = detect rate
on unwatermarked completions (negative control; SemStamp runs reuse the KGW
pilot's unwatermarked completions). pass@1 = execution against the dataset's
tests in a subprocess, `src/eval_pass1.py` (per-dataset program construction
lives in the dataloader modules; 10 s timeout for HumanEval/MBPP; for LCB,
6 s per test, tests capped at 20 per task, >10 MB test inputs skipped).

**Environments.** conda `watermark` (python 3.12, torch cu128,
transformers ≥ 5.13) for pilot runs; conda `vllm_server` (vllm 0.18,
transformers 4.57) for the MarkLLM+vLLM runs. Outputs are indexed by
watermark method, then dataset, with a subfolder only for the MarkLLM
reproduction: `out/{kgw,semstamp}/{humaneval,mbpp,livecodebench}[/markllm]/`
plus `out/similarity/`; pass@1 files sit next to the inference JSON they
evaluate. Code layout and the mandatory three-step inference pattern are
documented in `CLAUDE.md`.

## 2. Results

All watermarked-inference runs (Qwen3.5-4B; unwatermarked pass@1 baseline:
HF pilot 78.0% / 60.0%, vLLM 79.9% / 58.2%, LCB 41.75% shared by both
methods):

| method | implementation | engine | dataset | n | segmenter | strength | N_max | TPR | FP | mean z (wm) | mean z (unwm) | mean gen tokens (wm) | pass@1 (wm) | pass@1 (unwm) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| KGW | pilot | HF | HumanEval | 164 | — | δ=8 | — | **93.3%** (153) | 0.0% (0) | 15.7 | −0.89 | 476 | **1.8%** | 78.0% |
| KGW | pilot | HF | MBPP | 500 | — | δ=8 | — | **98.8%** (494) | 0.0% (0) | 21.1 | −1.19 | 501 | **0.4%** | 60.0% |
| KGW | MarkLLM | vLLM | HumanEval | 164 | — | δ=8 | — | **86.6%** (142) | 3.0% (5) | 14.3 | +0.66 | 449 | **10.4%** | 79.9% |
| KGW | MarkLLM | vLLM | MBPP | 500 | — | δ=8 | — | **97.4%** (487) | 1.6% (8) | 20.2 | +0.54 | 487 | **6.4%** | 58.2% |
| KGW | official | HF | LCB v1 | 400 | — | δ=8 | — | **92.5%** (370) | 0.0% (0) | 10.3 | −0.26 | 1007 | **0.0%** | 41.75% |
| SemStamp | pilot | HF | HumanEval | 164 | line | γ=0.25 | 32 | **5.5%** (9) | 2.4% (4) | 0.29 | +0.08 | 237 | **78.7%** | 78.0% |
| SemStamp | pilot | HF | MBPP | 500 | line | γ=0.25 | 32 | **7.8%** (39) | 2.6% (13) | 0.54 | +0.02 | 124 | **59.8%** | 60.0% |
| SemStamp | MarkLLM | vLLM | HumanEval | 164 | line | γ=0.25 | 100 | **7.9%** (13) | 2.4% (4) | 0.40 | +0.08 | 275 | **62.8%** | 79.9% |
| SemStamp | MarkLLM | vLLM | MBPP | 500 | line | γ=0.25 | 100 | **9.4%** (47) | 2.6% (13) | 0.66 | +0.02 | 143 | **55.0%** | 58.2% |
| SemStamp | official | HF | LCB v1 | 400 | sent | γ=0.25 | 32 | **19.0%** (76) | 3.25% (13) | 1.56 | +0.36 | 759 | **43.0%** | 41.75% |
<!-- | SemStamp | MarkLLM | vLLM | HumanEval | 164 | sent | γ=0.25 | 32 | **1.8%** (3) | 0.6% (1) | 0.14 | 0.00 | 236 | **78.7%** | 79.9% |
| SemStamp | MarkLLM | vLLM | MBPP | 500 | sent | γ=0.25 | 32 | **3.8%** (19) | 0.4% (2) | 1.36 | +0.24 | 122 | **58.6%** | 58.2% | -->

<!-- Validity and interpretation:

- **Detector cross-validation**: MarkLLM's own SemStamp detector, run on the
  pilot's completions, reproduces the pilot z-scores **bit-for-bit**
  (max |Δz| = 0.0 on all 164 + 500 tasks; nearpy LSH hyperplanes verified
  identical to the pilot's numpy replication). The two implementations'
  TPR differences come from generation (N_max 100 vs 32, different sampler)
  plus binomial noise, not from detection.
- **KGW watermarks code but destroys it**: pass@1 collapses (78→2%, 60→0.4%;
  vLLM repro 10.4% / 6.4%; LCB 41.75→0.0% — not one watermarked completion
  passes). Most watermarked completions degenerate into repetitive
  max-length output.
- **SemStamp preserves code but does not embed**: TPR sits 3–7 points above
  FP; watermarked valid-segment fraction ≈ 0.27–0.31 vs chance γ=0.25.
  Cause: 89% (HumanEval) / 68% (MBPP) of pilot segments — 82% / 75% in the
  repro — produced exactly **one** distinct LSH signature across all trials;
  ~77–83% of segments exhaust N_max. The next code line is semantically
  determined, so rejection sampling has nothing to choose between. With the
  original sentence segmenter TPR is lower still (a code completion has a
  median of 1–3 nltk "sentences", so the z-test has almost no segments).
  On LCB (authors' own code, harder contamination-controlled tasks) pass@1
  43.0% ≈ baseline but TPR 19.0% vs a 3.25% FP floor (mean z 1.56 vs the
  z>3 threshold), at a mean cost of 611 resampling trials ≈ 15 min/task.
  Notably, LCB completions average 24.8 nltk sentences (vs the 1–3 above),
  so the sent-mode z-test has plenty of segments there — the low TPR is
  code's low semantic entropy, not a segmentation artifact.
- The SemStamp-line vLLM pass@1 dip (62.8% vs pilot 78.7%) is a pipeline
  artifact — the repro splices accepted segments as text and re-tokenizes,
  vs the pilot's exact token-id concatenation; sent mode (whole-sentence
  splices) matches baseline at 78.7%.
- **Conclusion**: code generation is too low-entropy for both a token-level
  logit bias and semantic-level rejection sampling — KGW can only force the
  signal in by destroying the code, SemStamp cannot force it in at all.
  Natural next step: entropy-aware code watermarks (SWEET, EWD) or
  semantics-preserving degrees of freedom (identifiers, formatting). -->

## 3. SemStamp embedding-similarity study

Semantic diversity of repeated unwatermarked sampling
(`src/similarity_study.py`, one script for all datasets via the dataloader
interface): 10 random tasks per dataset (seed 42),
20 samples per task (same sampling settings as above), embedded with the
SemStamp SBERT embedder; pairwise cosine similarity over the C(20,2)=190
pairs per task, plus the number of distinct SemStamp LSH regions (of 8) the
20 samples cover. Full matrices: `out/similarity/similarity_study.json`.
The LiveCodeBench row (`--datasets livecodebench`,
`out/similarity/similarity_study_lcb.json`) follows the same protocol with
the LCB setting from §1 (LCB prompt with system message,
`max_new_tokens=1024`).

| dataset | mean pairwise cos sim (completion) | mean (extracted code) | mean distinct LSH regions /8 | tasks with all 20 samples in 1 region |
|---|---|---|---|---|
| HumanEval | 0.970 | 0.970 | 1.6 | 7/10 |
| MBPP | 0.919 | 0.911 | 2.4 | 4/10 |
| LiveCodeBench | 0.875 | 0.819 | 2.7 | 1/10 |

<!-- Many HumanEval/MBPP tasks yield 10–18/20 byte-identical completions; the
most diverse tasks observed (HumanEval/57: mean sim 0.75, 3 regions;
MBPP/388: 0.79, 4 regions) still cover fewer than half of the 8 regions.
This independently quantifies the SemStamp failure mechanism: with 1–2
reachable semantic regions per step and only 2 of 8 valid, a valid sample
usually does not exist at any trial budget.

LiveCodeBench is the most semantically diverse of the three (harder
problems, longer completions: almost no byte-identical duplicates, mean sim
0.875, 2.7 regions, best task abc324_b at 5/8) — and the diversity ordering
matches the SemStamp TPR ordering (HumanEval 5.5% < MBPP 7.8% < LCB 19.0%).
But even LCB's 2.7 reachable regions barely exceed the 2-of-8 valid at
γ=0.25, so rejection sampling still fails on most segments: more entropy
helps exactly as far as it goes, and code never has enough. -->
